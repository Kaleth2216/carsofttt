package com.carsoft.carsoft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarsoftApplicationTests {

	@Test
	void contextLoads() {
	}

}
